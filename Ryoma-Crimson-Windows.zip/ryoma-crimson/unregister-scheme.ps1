﻿# Switch to a different scheme before unregistering.
Remove-ItemProperty -Path 'HKCU:\Control Panel\Cursors\Schemes' -Name 'Ryoma Crimson' -ErrorAction SilentlyContinue
